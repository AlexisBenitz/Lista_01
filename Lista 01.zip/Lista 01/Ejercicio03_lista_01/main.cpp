#include <iostream>
#include "fecha.h"
using namespace std;

int main()
{
    Fecha miFecha;
    Fecha fechaact;
    int d,m,a;
    cout << "Este es un programa que calcula una fecha ACTUALIZADA:" << endl;
    cout << "\n ingrese el Dia" << endl;
    cin>>d;
    cout << "\n ingrese el Mes" << endl;
    cin>>m;
    cout << "\n ingrese el A�o " << endl;
    cin>>a;
    miFecha.getDia(d);
    miFecha.getMes(m);
    miFecha.getAnio(a);
    cout<<miFecha.PrintDate()<<endl;
    cout<<"\n Ingrese la nueva fecha"<<endl;
    cout << "\n ingrese el Dia" << endl;
    cin>>d;
    cout << "\n ingrese el Mes" << endl;
    cin>>m;
    cout << "\n ingrese el A�o " << endl;
    cin>>a;

    fechaact.getDia(d);
    fechaact.getMes(m);
    fechaact.getAnio(a);
    cout<<fechaact.PrintDate()<<endl;
    return 0;
}
