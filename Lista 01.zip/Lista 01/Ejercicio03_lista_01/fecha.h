#ifndef FECHA_H
#define FECHA_H
#include<iostream>


 using namespace std;

class Fecha
{



    private:
        int Dia;
        int Mes;
        int Anio;

        public:
Fecha(){}
Fecha(int D, int M, int A){
Dia=D;
Mes=M;
Anio=A;
}

getDia(int D){
    Dia=D;
}
getMes(int M){
    Mes=M;
}
getAnio(int A){
    Anio=A;
}
int setDia()const{
    return Dia;
}

int setMes()const{

    return Mes;
}
int setAnio()const{
    return Anio;
}
PrintDate(){

    if((Dia>=1&&Dia<=31 && Mes==1))

    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"enero/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=28 && Mes==2)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"febrero/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==3)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"marzo/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=30 && Mes==4)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"abril/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==5)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"mayo/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=30 && Mes==6)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"junio/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==7)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"julio/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==8)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"agosto/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=30 && Mes==9)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"septiembre/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==10)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"octubre/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=30 && Mes==11)
    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"noviembre/"<<Anio<<endl;

    }
    else if(Dia>=1&&Dia<=31 && Mes==12)

    {
        cout<<"la fecha en la que estas es:"<<Dia<<"/"<<"diciembre/"<<Anio<<endl;
    }
    else{
        cout<<"\n tu fecha no existe jajaja "<<endl;
    }





}





}








};

#endif // FECHA_H
